# heroku-buildpack-p7zip

A buildpack to install p7zip on a heroku dyno. For use with
[heroku-buildpack-multi](https://github.com/ddollar/heroku-buildpack-multi).
